package es.micine.app

import android.app.Activity
import android.app.AlertDialog
import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/**
 * Actualizaciones de la app: mira en GitHub si hay una compilación más nueva,
 * la descarga y abre el instalador de Android. Sin tiendas ni Downloader.
 */
class Updater(private val act: Activity) {

    companion object {
        const val BASE = "https://github.com/richtopro/mi-cine/releases/download/app-latest/"
        const val STATUS = "https://raw.githubusercontent.com/richtopro/mi-cine/build-log/status.txt"
        const val ASK_AGAIN_MS = 12 * 3600 * 1000L
    }

    private val main = Handler(Looper.getMainLooper())
    private val prefs = act.getSharedPreferences("micine", android.content.Context.MODE_PRIVATE)
    private var busy = false
    private var pendingInstall: File? = null

    fun currentVersion(): Long = try {
        val pi = act.packageManager.getPackageInfo(act.packageName, 0)
        if (Build.VERSION.SDK_INT >= 28) pi.longVersionCode else @Suppress("DEPRECATION") pi.versionCode.toLong()
    } catch (e: Exception) { 0L }

    /** manual = el usuario lo ha pedido desde el menú (avisa también si no hay nada nuevo). */
    fun check(manual: Boolean) {
        if (busy) return
        busy = true
        Thread {
            // GitHub deja aquí el resultado de la última compilación: «estado: success (compilación 7)»
            val latest = try {
                val txt = String(open(STATUS).inputStream.use { it.readBytes() }, Charsets.UTF_8)
                Regex("success\\D*(\\d+)").find(txt)?.groupValues?.get(1)?.toLong() ?: -1L
            } catch (e: Exception) { -1L }
            main.post {
                busy = false
                if (act.isFinishing) return@post
                val cur = currentVersion()
                when {
                    latest < 0 -> if (manual) toast("No se ha podido comprobar si hay actualizaciones. Inténtalo más tarde.")
                    latest <= cur -> if (manual) toast("Ya tienes la última versión (compilación $cur).")
                    else -> {
                        val skipped = prefs.getLong("skipVer", 0L) == latest &&
                            System.currentTimeMillis() - prefs.getLong("skipAt", 0L) < ASK_AGAIN_MS
                        if (manual || !skipped) offer(latest, cur)
                    }
                }
            }
        }.start()
    }

    private fun offer(latest: Long, cur: Long) {
        AlertDialog.Builder(act)
            .setTitle("Nueva versión de Mi Cine")
            .setMessage("Hay una versión nueva de la app (compilación $latest; tienes la $cur).\n\n¿La instalo ahora? Tarda menos de un minuto y no pierdes nada.")
            .setPositiveButton("Actualizar") { _, _ -> download(latest) }
            .setNegativeButton("Más tarde") { _, _ ->
                prefs.edit().putLong("skipVer", latest).putLong("skipAt", System.currentTimeMillis()).apply()
            }
            .show()
    }

    private fun open(url: String): HttpURLConnection {
        var u = url
        repeat(6) {
            val c = URL(u).openConnection() as HttpURLConnection
            c.connectTimeout = 15000
            c.readTimeout = 30000
            c.instanceFollowRedirects = false
            c.setRequestProperty("Cache-Control", "no-cache")
            c.setRequestProperty("User-Agent", "MiCineApp")
            val code = c.responseCode
            if (code in 300..399) {
                u = URL(URL(u), c.getHeaderField("Location")).toString()
                c.disconnect()
            } else if (code == 200) {
                return c
            } else {
                c.disconnect()
                throw IllegalStateException("HTTP $code")
            }
        }
        throw IllegalStateException("demasiadas redirecciones")
    }

    private fun download(ver: Long) {
        val bar = ProgressBar(act, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100; isIndeterminate = true }
        val txt = TextView(act).apply { text = "Descargando…"; setPadding(0, 0, 0, 16) }
        val box = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(60, 40, 60, 20)
            addView(txt); addView(bar)
        }
        val dlg = AlertDialog.Builder(act).setTitle("Actualizando Mi Cine").setView(box).setCancelable(false).show()
        Thread {
            try {
                val dir = if (Build.VERSION.SDK_INT >= 24) File(act.cacheDir, "updates") else (act.externalCacheDir ?: act.cacheDir)
                dir.mkdirs()
                val out = File(dir, "MiCine.apk")
                val c = open(BASE + "MiCine.apk")
                val total = c.contentLength.toLong()
                var done = 0L
                var lastPct = -1
                c.inputStream.use { inp ->
                    out.outputStream().use { o ->
                        val buf = ByteArray(64 * 1024)
                        while (true) {
                            val n = inp.read(buf)
                            if (n < 0) break
                            o.write(buf, 0, n)
                            done += n
                            if (total > 0) {
                                val pct = (done * 100 / total).toInt()
                                if (pct != lastPct) {
                                    lastPct = pct
                                    main.post { bar.isIndeterminate = false; bar.progress = pct; txt.text = "Descargando… $pct %" }
                                }
                            }
                        }
                    }
                }
                if (total > 0 && done != total) throw IllegalStateException("descarga incompleta")
                out.setReadable(true, false)
                main.post { dlg.dismiss(); install(out) }
            } catch (e: Exception) {
                main.post { dlg.dismiss(); toast("No se pudo descargar la actualización: ${e.message}") }
            }
        }.start()
    }

    private fun install(apk: File) {
        if (Build.VERSION.SDK_INT >= 26 && !act.packageManager.canRequestPackageInstalls()) {
            pendingInstall = apk
            AlertDialog.Builder(act)
                .setTitle("Falta un permiso")
                .setMessage("Android pide permiso para que Mi Cine pueda instalar su propia actualización.\n\nEn la pantalla que se abre, activa «Permitir de esta fuente» y vuelve atrás: la instalación seguirá sola.")
                .setPositiveButton("Abrir ajustes") { _, _ ->
                    try {
                        act.startActivity(Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + act.packageName)))
                    } catch (e: ActivityNotFoundException) {
                        toast("Busca en Ajustes → Aplicaciones → Mi Cine → «Instalar aplicaciones desconocidas» y actívalo.")
                    }
                }
                .setNegativeButton("Cancelar") { _, _ -> pendingInstall = null }
                .show()
            return
        }
        pendingInstall = null
        val uri = if (Build.VERSION.SDK_INT >= 24) Uri.parse("content://${ApkProvider.AUTHORITY}/MiCine.apk") else Uri.fromFile(apk)
        val i = Intent(Intent.ACTION_VIEW)
            .setDataAndType(uri, "application/vnd.android.package-archive")
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            act.startActivity(i)
        } catch (e: Exception) {
            toast("No se pudo abrir el instalador: ${e.message}")
        }
    }

    /** Al volver de los ajustes del permiso, sigue con la instalación. */
    fun onResume() {
        val apk = pendingInstall ?: return
        if (Build.VERSION.SDK_INT >= 26 && act.packageManager.canRequestPackageInstalls()) install(apk)
    }

    private fun toast(msg: String) = Toast.makeText(act, msg, Toast.LENGTH_LONG).show()
}
